# Sonderfälle (knapp, mit Quelle)

Rechtliches immer nur **allgemein** einordnen, keine Einzelfall-Fristen ausrechnen; bei Bedarf auf Beratung verweisen. Zahlen mit Stand nennen; ist Websuche an, vor dem Nennen kurz aktualisieren.

## Inhalt
1. Geld-Grenzen 2026/2027 (Mindestlohn, Minijob, Praktikum, Werkstudent)
2. Lebenslauf-Situationen: Lücke, Wiedereinstieg, Studien-/Ausbildungsabbruch
3. Wege: Initiativbewerbung, Teilzeitausbildung, PiA, Anzeige offline
4. Nutzer bringt fertigen ChatGPT-Text mit
5. Ältere Bewerber, Sie/Du, Schulabschluss
6. Private Angaben
7. Formular-Grenzen (Upload-Limits, Zeichen)

---

## 1. Geld-Grenzen

| Wert | 2026 | ab 01.01.2027 | Quelle (Stand) |
|---|---|---|---|
| Gesetzlicher Mindestlohn | 13,90 €/Std. | 14,60 €/Std. | Bundesregierung, bundesregierung.de „Mindestlohn steigt“ (21.09.2026) |
| Minijob-Grenze | 603 €/Monat | 633 €/Monat | ebd.; Deutsche Rentenversicherung PM 21.11.2025 |

- Ausnahmen vom Mindestlohn u. a.: Auszubildende (dafür Mindestausbildungsvergütung, `nach_dem_gespraech.md`), **Pflichtpraktika** laut Studien-/Schulordnung und **freiwillige Orientierungspraktika bis 3 Monate** (§ 22 MiLoG; z. B. Uni Göttingen „Praktikum und Mindestlohn“). Freiwilliges Praktikum über 3 Monate: Mindestlohn. Darum im Anschreiben/Formular angeben: Pflicht- oder freiwilliges Praktikum, Zeitraum.
- **Werkstudent:** In der Vorlesungszeit **höchstens 20 Std./Woche** (mehrere Jobs zusammen), sonst entfällt das „Werkstudentenprivileg“. Mehr nur abends/nachts/am Wochenende oder in den Semesterferien, zusammen höchstens 26 Wochen im Jahr. Beiträge: nur Rentenversicherung; keine Kranken-, Pflege-, Arbeitslosenversicherung über den Job – die studentische KV (oder Familienversicherung) bleibt (Barmer, „Werkstudent“, abgerufen 11/2026). In die Bewerbung: Studiengang, Semester, Stunden/Woche, ab wann, wie lange.
- **Minijob:** Verfügbarkeit (Tage/Uhrzeiten), Start, Erfahrung zählen; Anschreiben meist 3–5 Sätze in Mail/Formular.

## 2. Lebenslauf-Situationen

- **Lücke** (> ~3 Monate): ins Profil (`profil.luecken`), im Lebenslauf kurz und ehrlich benennen: „Berufliche Orientierung“, „Pflege eines Angehörigen“, „Elternzeit“, „Reise/Sprachkurs“, „Jobsuche, parallel Online-Kurs X“. Diagnosen nennt niemand.
- **Wiedereinstieg** (nach Elternzeit, Pflege, Krankheit, Ausland): Zeitraum als eigene Zeile („Familienzeit“), dabei Erworbenes nur, wenn der Nutzer es nennt (Ehrenamt, Kurse). Im Anschreiben ein Satz nach vorn („Ab 01.03. kann ich 30 Stunden pro Woche arbeiten“). Teilzeit-Wunsch offen nennen, wenn wichtig. Hilfe: Berufsberatung im Erwerbsleben der BA, Jobcenter, Beratungsstellen „Frau und Beruf“. Rechtliches (Elternzeit, Rückkehrrecht, Fristen) nicht ausrechnen – allgemein einordnen und an BA, Gewerkschaft oder Beratungsstelle verweisen.
- **Studien-/Ausbildungsabbruch:** ehrlich zeigen: „10/2024 – 09/2026 Studium Informatik (B.Sc.), FAU Erlangen-Nürnberg, ohne Abschluss“ + 1–2 belegte Stichpunkte (Fächer, Projekte). Im Anschreiben/Gespräch: kurz, sachlich, nach vorn („gemerkt, dass ich praktischer arbeiten will“), Grund vom Nutzer. Will der Nutzer verschleiern: Risiko erklären (Lücke fällt auf, Nachfrage im Gespräch, Täuschung bei zulässigen Fragen), Alternative formulieren; er entscheidet, du erfindest aber nichts.
- **Mehrere kurze Jobs/Wechsel:** gleichartige zusammenfassen („Aushilfsjobs Gastronomie, 2023–2025“), wenn der Nutzer zustimmt.

## 3. Wege

- **Initiativbewerbung:** Firma + Wunschbereich vom Nutzer; Karriereseite als Quelle (Firmenfakten mit Quelle, nur mit Zustimmung in den Text). Ansprechperson möglichst anrufen lassen. Anschreiben: warum diese Firma, was er anbietet, ab wann. Betreff „Initiativbewerbung als …“.
- **Teilzeitausbildung:** seit 2020 für alle möglich, wenn der Betrieb zustimmt; die Ausbildung dauert dann entsprechend länger (§ 7a BBiG, gesetze-im-internet.de). Wunsch im Anschreiben nennen; IHK/HWK beraten.
- **PiA (praxisintegrierte Ausbildung, z. B. Erzieher/in):** vergütet, Praxis beim Träger + Fachschule. Meist **zwei Bewerbungen**: beim Träger (Kita) und bei der Fachschule – Fristen der Fachschule früh prüfen (Nutzer fragt dort nach). Regional unterschiedlich.
- **Anzeige offline** (Zeitung, Aushang, Radio, Bekannte): Foto/Screenshot hochladen oder abtippen lassen; fehlt etwas (Ansprechperson, Frist, Weg): eine Frage oder „anrufen und nachfragen“ vorschlagen. Nie ergänzen.

## 4. Mitgebrachter ChatGPT-Text

1. Text als `.txt` speichern, `endcheck.py … --typ anschreiben` (zeigt Floskeln, Länge). Die fehlende E-Mail bei reinem Brieftext ignorieren.
2. Ehrlich sagen: KI-Texte fallen Personalern oft auf (glatt, austauschbar, aufgebläht).
3. **Nichts daraus ungeprüft übernehmen:** Jede Behauptung (Rolle, Zahl, Kenntnis) ist erst Fakt, wenn der Nutzer sie bestätigt – dann ins Profil. Danach neu aus dem Profil bauen; gute, belegte Formulierungen des Nutzers dürfen bleiben.

## 5. Ältere Bewerber, Sie/Du

- Schreibt der Nutzer „Sie“, ist er erkennbar älter oder möchte er es: auf **Sie** wechseln (`meta.anrede_form`). Im Zweifel einmal kurz anbieten.
- Mit Berufserfahrung: **keine** Schulnoten-/Schulfächer-Fragen; Schule nur als höchster Abschluss mit Jahr. Fokus auf letzte 10–15 Jahre, Ergebnisse, Weiterbildungen. Lebenslauf bis 2 Seiten.
- Geburtsdatum ist freiwillig; nicht nachfragen.

## 6. Private Angaben

Kinder, Familienstand, Religion, Staatsangehörigkeit, Gesundheit, Schwerbehinderung: **nicht abfragen**, nicht in den Lebenslauf. Nur wenn der Nutzer es von sich aus aufnehmen will, kurz die Vor- und Nachteile nennen; er entscheidet. Ausnahme: Arbeitserlaubnis/Aufenthaltsstatus kann bei Nicht-EU-Bürgern für die Firma wichtig sein – nur ansprechen, wenn der Nutzer das Thema bringt. Schwerbehinderung offenlegen ist freiwillig (Vor-/Nachteile: Integrationsfachdienst, Schwerbehindertenvertretung).

## 7. Formular-Grenzen

- **Upload-Limit** („max. 2 Dateien“, „max. 5 MB“) in `ziel.upload_limit`. Beispiel 2 Dateien: 1) Lebenslauf, 2) Anschreiben + alle Zeugnisse als eine PDF (`pdf_zusammenfuegen.py`). Ohne Anschreiben-Feld: Lebenslauf + Zeugnisse-PDF.
- **Zeichenlimits** je Feld in `formular[].limit`; `endcheck.py --typ formular` prüft sie.
- Pflichtfelder nie mit „siehe Lebenslauf“.
